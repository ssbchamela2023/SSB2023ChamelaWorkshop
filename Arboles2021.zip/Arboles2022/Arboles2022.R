###############################################################################
#																			   
#	Bioiformatica Filogenética 2021											   
#	Introducción a la manipulación de árboles en R 		
#	Elaborado por
#		Ivalú Cacho Gonzalez 
#		ivalu.cacho@ib.unam.mx		
#	Algunas modificaciones por	
#		Ricardo García-Sandoval		
#		r.garciasandoval@ciencias.unam.mx @rgarciasandoval
#
#	   																	   
## OBJETIVO:
#   • Introducción al uso de R para implementar el método filogenético comparativo.
#			   																	     			
## ACTIVIDAD:
#   • Manipular árboles filogenéticos en R.
#				   																	   
## DATOS:
#   • los árboles muestreados por la MCMC en un análisis de MrBayes de un grupo de hongos (archivos .con y .tre).
#   • una matriz morfológica con datos sobre forma de la espora en este grupo de hongos (archivo .csv).
#
#	Datos tomados de García-Sandoval et al. 2005 Mycotaxon 94:265-292
#
##############################################################################




###################################################
### PRELIMINARES
###################################################

###  Cargar librerías
# install.packages("ape", dependencies=TRUE, repos="http://cran.rstudio.com")
			library("ape")
			library("geiger")
			library("phytools")


###  Definir directorio de trabajo


		 setwd("~/Desktop/Intro.APE")
			
### Si deseas saber en que directorio estás usa
		getwd()
		
###Posiblemente necesitas saber si los archivos se encuentran en el directorio
		dir()
			o
		list.files()
		
###Si la ventana acumuló mucha información limpiala con Cmd+Opt+L (en windows Ctl+L)

###################################################
###  PARTE 1:  Manipulacion de árboles (un vistazo)
###################################################

###  Cargar el árbol, con longitud de ramas
			arbol <- read.nexus("arbol_nexus.tre")
#Si el árbol es formato Newik utiliza
#			arbol <- read.tre("arbol_newick.tre")

###  Si damos como comando el nombre del objeto (en este caso, 'arbol'), obtendremos información sobre el objeto en cuestión

			arbol  			
			
			#						*CONTESTAR*
			# 'arbol' tiene ______ terminales y _____nodos internos
			# 'arbol' es enraizado (si/no?) ______ 
			# 'arbol' tiene longitudes de rama (si/no?) ______ 
			


###  En R, hay varios tipos de objetos: vector, data.frame, matrix, list, array, etc
###  Para ver qué tipo de objeto de R es 'arbol', usamos la función class()
		
			class(arbol)   
			
			# arbol es un objeto de clase "phylo"
			# Más adelante usaremos objetos que contienen múltiples árboles, serán
			# multiphylo, algunos modelos estan implementados para correr en objetos
			# phylo pero no corren en multiphylo



###  Para ver cómo esta estructurada la información del objeto 'arbol', usamos la función str()
			str(arbol)   
			
			# este comando revela que un objeto de clase "phylo" es una lista de 4 cosas/objetos:
						# List of 4
						# $ edge       : int [1:29, 1:2] 17 17 18 19 20 21 22 22 23 24 ...
						# $ Nnode      : int 14
						# $ tip.label  : chr [1:16] "Clavariadelphus_pistillaris" "Clavulinopsis_amoena" "Clavulinopsis_fusiformis" "Clavulinopsis_helvola" ...
						 # $ edge.length: num [1:29] 0.0656 0.0332 0.136 0.0193 0.0167 ...
					


###  Podemos ver cada uno de estos elementos por separado, de la siguiente manera:
		    arbol$tip.label  		# --> nos da los nombres de las terminales 
		    arbol$Nnode  			# --> nos da el número de nodos internos 
		    arbol$edge.length   	# --> nos da la longitud de las ramas 
		    mean(arbol$edge.length) # --> si estamos interesados en conocer la longitud promedio del árbol
		    arbol$edge  			# --> nos da una matriz de 29 hileras y 2 columnas con las ramas 
		    
		    class(arbol$edge)		# --> "matrix"
		    #  Esta matriz representa las combinaciones únicas de números de nodo y terminales, definiendo cada segmento o rama del árbol


###  Graficando el árbol
			plot(arbol)   

			plot(arbol, cex=0.8)   # cex nos permite manipular el tamaño de la fuente
			plot(arbol, cex=0.8, label.offset=0.015,, edge.width =3)   # label.offset recorre los nombres, edge.width determina el ancho de la rama
	    	tiplabels()          # muestra el número asignado a cada terminal
	   		nodelabels()         # muestra el número asignado a cada nodo
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))  			# adj ajusta la ubicación de la etiqueta
			
			
			plot(arbol, type="fan", cex=0.8) #podemos visualizar el árbol de diferentes formas
			plot(arbol, type="unrooted", cex=0.8)
			plot(arbol, type="unrooted", cex=0.6, label.offset=0.02)   # label.offset recorre los nombres




###  Podemos ver que las ramas del clado Ramariopsis unen:

			#						*CONTESTAR*
			# ¿Qué ramas conectan los siguientes pares de nodos? y ¿Cuál es la longitud de cada una de esas ramas?
			# 26 -- 8 	Rama: 		Longitud:
			# 26 -- 27	Rama: 		Longitud:
			# 27 -- 7	Rama: 		Longitud:
			# 27 -- 6	Rama: 		Longitud:
			# 18 -- 17	Rama: 		Longitud:


###  Rotando clados  --> los nodos conservan su numeración original

			arbol.rot <- rotate(arbol, node=23)
			plot(arbol.rot)   
			
# Enraizar el árbol, ponemos la raiz en los Gomphales, pero más o menos en medio de la rama (revisa la longitud)
# esto lo hacemos solo para efectos esteticos
# Vamos a usar una sola espacie para orientar el cldograma (enraizarlo)
# Usaremos la especie Clavariadelphus pistillaris

con.raiz.al.margen<-reroot(arbol, 1)
plot(con.raiz.al.margen)

# La raíz se ve un poco extraña, porque está demasiado cerca de la rama.
# Vamos dibujar los nodos un poco más balanceados, poniendo "media rama" de un lado
# y "media rama" del otro
# Vamos a buscar la longitud de una rama en específico
# primaro vamos a ponerle las etiquetas a los nodos 
# luego ubicamos la rama de interes en el arbol sin raíz y vemos su longitud
# vamos a poner la raíz más o menos en medio


con.raiz.en.medio<-reroot(arbol, 1, position=0.03)
plot(con.raiz.en.medio)

#Ahora vamos a escribir el árbol en un nuevo archivo
write.tree(con.raiz.en.medio, file = "con.raiz.en.medio.tre")

#Ahora hacemos un PDF con el árbol
pdf("con.raiz.en.medio.pdf")
plot(con.raiz.en.medio)
dev.off()

			#						*CONTESTAR*
			# Usando FigTree abre el árbol que acabas de escribir y comparalo con el 
			# se general con el comando "plot()"
			# ¿Qué diferencia encuentras en la representación gráfica de la filogenia?

# Clavariadelphus y Gomphus son un grupo monofilético (Gomphales), pero dan la falsa 
# impresión de ser parafiléticos. Para "corregir" eso vamos a enrraizar con el nodo que conecta
# al los Gomphales con el resto de del árbol


			#						*CONTESTAR*
			# Este es un ejercicio para aplicar lo que sabes.
			# 0. Identifica el nodo que corresponde al ACMR de los Gomphales, ¿cuál es? (Gomphales incluye Clavariadelphus y Gomphus)
			# 1. Identifica el nodo en el que los Gomphales se conectan con el resto del árbol, ¿cuál es?
			# 2. Usa ese nodo para re-enraizar colocando la raíz "al margen".
			# 	Consejo: genera un nuevo objeto con esta nueva raíz, para que no sobre escribas
			# 	los que ya tienes en RAM, como veras R es un tragón de RAM
			# 3. Visualiza el árbol
			# 4. Genera un PDF con ese árbol
			# 5. Identifica la rama que conecta al ACMR de Gomphales con el nodo en que se conectan ¿cuál es?.
			# 	Consejo: son los nodos de la pregunta 0 y 1
			# 6. ¿Qué longitud tiene esa rama?
			# 7. Re-enraiza ahora dibujando la raíz en la mitad
			# 8. Visualiza el nuevo árbol y genera un PDF con el

			# ESCRIBE EL CÓDIGO Y LAS RESPUESTAS AQUí:




###  Graficando dos (o más en un panel)
			par(mfrow=c(1,2), mar=c(1,1,1,1))  
			
			# con la función mfrow especificamos el número de hileras y columnas en las que se va a dividir el panel
			# con la función mar especificamos los márgenes

			plot(con.raiz.en.medio, cex=0.8, label.offset=0.015)
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))	

			plot(con.raiz.al.margen, cex=0.8, label.offset=0.015)
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))	


###  'peinadito'   --> los nodos conservan su numeración original

			arbol.der <- ladderize(con.raiz.en.medio, right = TRUE)
			arbol.izq <- ladderize(con.raiz.en.medio, right = FALSE)

			plot(arbol.der, cex=0.8, label.offset=0.015)   
			plot(arbol.izq, cex=0.8, label.offset=0.015)  
			  
			plot(arbol.der, cex=0.8, label.offset=0.015)   
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))

			plot(arbol.izq, cex=0.8, label.offset=0.015)  
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))
			
			
			#						*CONTESTAR*
			# Genera un PDF en donde pongas lado a lado
			# a) el árbol enraizado con Clavariadelphus
			# b) el árbol enraizado con los Gomphales
			# ESCRIBE EL CÓDIGO AQUí:


# Ahora árboles enfrentados, esto se ve más claramente si usas un cladograma en ves de un filograma

			cladograma<-read.nexus("cladograma.tre")
			par(mfrow=c(1,2), mar=c(0.01,0.01,0.01,0.01)) 
			plot(cladograma, cex=0.8)   
			plot(cladograma, cex=0.8, direction="leftwards") 
	
#Inclusive puedes graficar enfrentados con una misma leyenda, por ejemplo para contrastar la distrbución de un carácter
#pdf("caraAcara.pdf", width=7.5, height=5)
layout(matrix(1:3,1,3),widths=c(0.3,0.3,0.3))
plotTree(cladograma,ftype="off")
plot.new()
plot.window(xlim=c(-0.1,0.1),ylim=c(1, length(cladograma$tip.label)))
par(cex=0.8)
text(rep(0,length(cladograma$tip.label)), 1:length(cladograma$tip.label),cladograma$tip.label)
plotTree(cladograma,ftype="off",direction="leftwards")
#dev.off()		
						
###  Definiendo las especies que componen un clado
		
			# función 'tips' del paquete 'geiger'
	  		  clado_ramari <- tips(arbol, node=26) # el nodo 26 es el MRCA del clado
	   		 clado_ramari


###  Podar un árbol --> eliminar especies

	 arbol_noramari <- drop.tip(arbol, clado_ramari) 
	 plot(arbol_noramari)
	 
###  Revisamos La numeración de nodos y terminales 
	nodelabels(cex=0.7)
	tiplabels(cex=0.7)

#Esta función te da la lista de descendientes del nodo que le indicas
	clavuli <- tips(arbol, node=20)
	clavuli

#Vamos a recortar un pedazo del árbol, digamos que solo queremos conservar los Agaricales (de Clavaria hasta Ramariopsis)

	agaricales <- extract.clade(arbol.der, node=21)
	plot(agaricales)
	
	
	
			#						*CONTESTAR*
			# Con el objeto "agaricales" genera un archivo NEXUS y un PDF
			# ESCRIBE EL CÓDIGO Y LAS RESPUESTAS AQUí:



###  seleccionando las ramas de un clado 

  # función which.edge() de ape.

    ramas_cladoramari <- which.edge(arbol, clado_ramari) 
    
    ramas_cladoramari 		# this debe dar: 15 16 17 18
    
    

### si queremos ver las longitudes de rama de este clado:

	arbol$edge
	arbol$edge.length[15:18] 

#Por cierto ¿cuántos objetos tendremos en RAM?

ls()

#Para remover alghun objeto de la memoria
#rm(objeto_a_remover)	

rm(clado_ramari)


#Si queremos eliminar una especie de Clavaria
	 solo.una.Clavaria <- drop.tip(agaricales, "Clavaria_fragilis") 
	 plot(solo.una.Clavaria)


			plot(agaricales, cex=0.8, label.offset=0.015)  
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))

			plot(solo.una.Clavaria, cex=0.8, label.offset=0.015)  
			tiplabels(cex=0.5, adj=c(-0.5,0.5))
			nodelabels(cex=0.5, adj=c(0.5,0.5))


			#						*CONTESTAR*
			# Con el objeto "agaricales" genera un archivo NEXUS y un PDF
			# ESCRIBE EL CÓDIGO Y LAS RESPUESTAS AQUí:









###################################################
###  PARTE 2:  Visualizando los datos
###################################################


### Cargar el árbol
### Este es un árchivo con información sobre la forma de las esporas
### en un grupo de especies 
### el = elongadas
### sg = subglobosas
### gl = globosas

			datos.orig <- read.csv("morfo2.csv")

			head(datos.orig)
			class(datos.orig)
			rownames(datos.orig) <- datos.orig[,1]
			
			head(datos.orig)
			
### Creando columnas de color

	datos.orig$color <- datos.orig$forma_espora
	datos.orig$color <- as.character(datos.orig$forma_espora)
	datos.orig$color[datos.orig$forma_espora=="el"]
	datos.orig$color[datos.orig$forma_espora=="el"] <- "magenta"
	datos.orig$color[datos.orig$forma_espora=="gl"] <- "blue"
	datos.orig$color[datos.orig$forma_espora=="sg"] <- "green"
	datos.orig$color <- factor(datos.orig$color)
	
	head(datos.orig)
	
	write.csv(datos.orig, 'morfo2MOD.csv', row.names=F)


### Ordenando los datos conforme el arbol --> esto es MUY importante!!!

	arbol.der$tip.label
	rownames(datos.orig)
	identical(arbol.der$tip.label, rownames(datos.orig))  # FALSE
	datos.ord <- datos.orig[match(arbol.der$tip.label, rownames(datos.orig)),] 
	identical(arbol.der$tip.label, rownames(datos.ord))  # TRUE


			
### Visualizando datos

    plot(arbol.der, label.offset=0.03, edge.width =3)
    tiplabels(pch=21, col="black", bg=datos.ord$forma_espora, cex=2)
    tiplabels(pch=21, col="black", bg=as.character(datos.ord$color), cex=2)


### También podemos pintar los nombres, y usar tiplabels para otro caracter

     plot(arbol.der, label.offset=0.03, edge.width =3, tip.col=as.character(datos.ord$color))
     


			#						*CONTESTAR*
			# Genera un PDF en donde esten los dos árboles, el de colores en las puntas y el de 
			# nombres con colores
			# ESCRIBE EL CÓDIGO Y LAS RESPUESTAS AQUí:





###################################################
MISCELANEOS
###################################################


##########################################################
### Seleccionar un árbol de máxima credibilidad de clados
#Al final el árbol se puede leer en FigTree, pero no está 
#anotado, esto es, no contienen una rango de edades
##########################################################

library("phangorn")
library("phytools")
setwd("~/Desktop/ejeRcicios")

arboles <- read.nexus("archivo.en.nexus.nex")
mcc <- maxCladeCred(arboles, rooted=F)
write.nexus(mcc, file="mcc.tre", translate=T)

plot(mcc)



###### Sub muestra de los árboles muestreados en una MCMC


library(ape)

beastreesAll <- read.nexus("infile.nex.run1.t")
beastreesAll
class(beastreesAll) #debe ser un objeto "multiPhylo"
beastreesAll[[1]]  #leer un árbol específico de la muestra

###############
# Seleccionar un subconjunto de árboles


beast1000 <- beastreesAll[sample(1:length(beastreesAll), 1000, replace = F)]  # todos
beast1000 <- beastreesAll[sample(251:length(beastreesAll), 50, replace = F)]  # eliminando el burnin

class(beast1000)  #debe ser un objeto "multiPhylo"

####################
#Submuestra de cualquier data.frame
#Esta es una submuestra de 3180 datos (50%) de un data.frame original (datos) que contenia 
#6360 datos con 20 variables cada dato

muestra <- datos[sample(1:nrow(datos), 3180, replace=F),]

######### como objeto de R:

save(beast1000, file="1000arboles_beast_101216.Rdata")


######### o en formato NEXUS:

write.nexus(beast1000, file="50arbolitos.tre", translate=T)


help(sample)


###########################################################################################

#Como mezclar dos archivos .t de MrBayes para llevarlos a TreeAnotator. 
#Comandos desde la terminal UNIX


#!/bin/bash
#change working directory
cd /file/path/to
#gets the taxon block from one of the files (in this case the first one) and makes a new tree file called "combined.t"
#revisar que el término "tree gen" sea el que corresponde a las etiquetas de los árboles
grep -v -e "tree.gen" -e "end;" run1.t > combined.t
#searches for the trees using the term "tree rep" in both tree files and dumps them into alternate lines in the combined file 
paste -d"\n" <(grep "tree.gen" run1.t) <(grep "tree.gen" run2.t) >> combined.t
#adds the closing nexus code
echo "end;" >> combined.t

#Mover archivos que tienen un contenido específico hasta otro folder
#Hacer un grep recursivo (R, busca dentro de subdirectorios) de la palabra "Psathy", el output es un path
#de cada archivo (l), los archivos son movidos al folder "nuevo" emplenado el comando "mv"
#Esté comando solo opera en el folder en que estas situado, no busca por todo el disco duro, solo en el folder actual
#el punto después del texto a buscar le indica que solo busque es el directorio actual


mv `grep -Rl  Psathy .` /Users/rgarciasandoval/Filogenias/R/nuevo/
